# Changelog
- Unreleased
  - Initial Doxygen docs scaffold, architecture & dev guide pages.
